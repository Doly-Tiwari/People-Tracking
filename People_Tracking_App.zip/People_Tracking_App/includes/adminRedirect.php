<?php
$Index="index.php";
$Login="a_login.php";
$Logout="logout.php";
$Requests = "requests.php";
$Signup="a_signup.php";
$Request = "single-request.php";
$ForgotPassword = "a_forgot_password.php";
$ResetPassword = "a_reset_password.php";
?>