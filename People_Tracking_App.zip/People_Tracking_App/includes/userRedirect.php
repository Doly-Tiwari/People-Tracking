<?php
$Index="index.php";
$Login="u_login.php";
$Logout="logout.php";
$UpdateRequest = "u_update_request.php";
$NewRequest = "u_request.php";
$Request = "u_fetch_request.php";
$ForgotPassword = "u_forgot_password.php";
$ResetPassword = "u_reset_password.php";
?>