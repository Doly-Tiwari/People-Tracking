 <!--=========== Start Footer SECTION ================-->
 <footer id="footer">
      <!-- Start Footer Bottom -->
      <div class="footer-bottom">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <p>Design & Developed By <a rel="nofollow" href="#">TEAM 68 FSD</a></p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!--=========== End Footer SECTION ================-->

    <!-- jQuery Library  -->
    <script src="../js/jquery.js"></script>    
    <!-- Bootstrap default js -->
    <script src="../js/bootstrap.min.js"></script>
    <!-- slick slider -->
    <script src="../js/slick.min.js"></script>    
    <script type="text/javascript" src="../js/modernizr.custom.79639.js"></script>      
    <!-- counter -->
    <script src="../js/waypoints.min.js"></script>
    <script src="../js/jquery.counterup.min.js"></script>
    <!-- Doctors hover effect -->
    <script src="../js/snap.svg-min.js"></script>
    <script src="../js/hovers.js"></script>
    <!-- Photo Swipe Gallery Slider -->
    <script src='../js/photoswipe.min.js'></script>
    <script src='../js/photoswipe-ui-default.min.js'></script>    
    <script src="../js/photoswipe-gallery.js"></script>

    <!-- Custom JS -->
    <script src="../js/custom.js"></script>
    <script src="https://kit.fontawesome.com/1667778526.js" crossorigin="anonymous"></script>
     
  </body>
</html>